import subprocess
import json
import time

def classify_failures():
    print("[INFO] Starting Failure Classification...")
    result = subprocess.run(
        ["kubectl", "get", "pods", "-o", "json"],
        capture_output=True, text=True
    )
    pods = json.loads(result.stdout)

    for pod in pods['items']:
        name = pod['metadata']['name']
        phase = pod['status'].get('phase', '')
        state = pod['status'].get('containerStatuses', [{}])[0].get('state', {})

        if phase == "Failed" or "terminated" in state:
            reason = state.get('terminated', {}).get('reason', 'Unknown')
            print(f"[FAILURE] Pod: {name}, Reason: {reason}")
            print("[CLASSIFICATION] Type: ApplicationFailure")

if __name__ == "__main__":
    classify_failures()
